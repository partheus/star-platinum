# talent-sketchers-test

This website is modelled after [mastodon.org](https://mastodon.social/home). Simple comment toggling and updating of likes is available.

My websites and portfolio are linked inside for reference. Thank you!
