document.addEventListener('DOMContentLoaded', () => {
    // Handle Like Button Clicks
    const likeButtons = document.querySelectorAll('.like-btn');
    likeButtons.forEach(button => {
        button.addEventListener('click', (event) => {
            const likeCount = event.target.querySelector('.like-count');
            let count = parseInt(likeCount.textContent);
            likeCount.textContent = count + 1; // Increment the like count
        });
    });

    // Handle Comment Toggle Button Clicks
    const commentToggleButtons = document.querySelectorAll('.comment-toggle-btn');
    commentToggleButtons.forEach(button => {
        button.addEventListener('click', (event) => {
            const commentsSection = event.target.parentElement.nextElementSibling;
            if (commentsSection.style.display === 'none' || commentsSection.style.display === '') {
                commentsSection.style.display = 'flex'; // Show comments
            } else {
                commentsSection.style.display = 'none'; // Hide comments
            }
        });
    });
});

// This page will not retain the numbers and the likes will reset after a refresh. This is a demo functionality!